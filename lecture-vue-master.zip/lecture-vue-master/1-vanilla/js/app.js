import MainController from './controllers/MainController.js'

document.addEventListener('DOMContentLoaded', () => {
  MainController.init()
})